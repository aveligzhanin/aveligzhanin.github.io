//---------------------------------------------------------------------------

#ifndef UExcelH
#define UExcelH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------

#include "XMLDoc.hpp"

class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TEdit *E_SourceFile;
    TButton *B_DoIt;
    TEdit *E_TempDir;
    TEdit *E_DestFile;
    TLabel *L_SourceFile;
    TLabel *L_DestFile;
    TLabel *L_TempDir;
    TEdit *E_Cell;
    TLabel *L_Cell;
    TEdit *E_Value;
    TLabel *L_Value;
    void __fastcall B_DoItClick(TObject *Sender);
private:	// User declarations
    void __fastcall GetVariant(AnsiString str, VARIANT &var);
    bool __fastcall UnZipFile(
        AnsiString SourceDir, AnsiString SourceFile, AnsiString DestDir
    );
    bool __fastcall EditCell(
        _di_IXMLDocument xmlSheet1, _di_IXMLDocument xmlSharedStrings
        , AnsiString CellName, AnsiString Value
    );
    _di_IXMLNode __fastcall FindChildNode(
        _di_IXMLNode node, AnsiString FoundName
    );
    _di_IXMLNode __fastcall FindNode(
        _di_IXMLNode parent, AnsiString NodeStr
    );
    _di_IXMLNode __fastcall FindNodeAttr(
        _di_IXMLNode node, AnsiString NodeName, AnsiString AttrName, AnsiString Value
    );
    AnsiString __fastcall GetRowName(AnsiString CellName);
    bool __fastcall SetNodeValue(
        _di_IXMLNode xNode, AnsiString NodeName, AnsiString Value
    );
    AnsiString __fastcall GetUnique();
    int __fastcall ReversePos(
        const AnsiString S, const AnsiString Match
    );
    void __fastcall AssertDir(
        const AnsiString p
    );
    void __fastcall ParseCellRowCol(
        AnsiString Cell, int &row, int &col
    );
    _di_IXMLNode __fastcall FindCellNode(
        _di_IXMLDocument xmlDoc, AnsiString CellName
    );
    bool __fastcall SaveXml(
        _di_IXMLDocument xmlDoc, AnsiString FileName
    );
    AnsiString __fastcall SetSharedStrings(                                     // ������ ���������� ������ 'S' � sharedStrings.xml
        _di_IXMLDocument xmlSharedStrings, AnsiString S
    );
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
